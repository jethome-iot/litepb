# LitePB All Types Showcase

A comprehensive example demonstrating **ALL** Protocol Buffer types supported by LitePB.

## What This Example Shows

This example is a complete reference for all Protocol Buffer field types:

### Scalar Types (Variable-length encoding)
- `int32`, `int64` - Standard signed integers
- `uint32`, `uint64` - Unsigned integers
- `sint32`, `sint64` - Signed integers with zigzag encoding (efficient for negative numbers)
- `bool` - Boolean values
- `string` - UTF-8 text strings
- `bytes` - Raw binary data

### Fixed-Width Types (Always use exact byte size)
- `fixed32`, `fixed64` - Unsigned fixed-width integers (4/8 bytes)
- `sfixed32`, `sfixed64` - Signed fixed-width integers (4/8 bytes)
- `float` - 32-bit floating point
- `double` - 64-bit floating point

### Complex Types
- **Enum** - Enumerated values with named constants
- **Nested Messages** - Messages within messages
- **Repeated Fields** - Arrays/lists (packed and unpacked encoding)
- **Map Fields** - Key-value dictionaries (string→int32, string→message)
- **Oneof** - Union type (only one field can be set at a time)

## Files

- `proto/showcase.proto` - Complete Protocol Buffer definition with all types
- `src/main.cpp` - Comprehensive demonstration of encoding/decoding all types
- `platformio.ini` - PlatformIO configuration

## How to Run

From this directory (`examples/serialization/all_types/`), run:

```bash
pio run -e all_types
.pio/build/all_types/program
```

Or from the project root:

```bash
cd examples/serialization/all_types && pio run -e all_types && .pio/build/all_types/program
```

## Expected Output

The example will:
1. Create a `TypeShowcase` message with all field types populated
2. Display the original data for each type
3. Serialize to binary Protocol Buffer format
4. Deserialize back to a message
5. Verify all fields match the original values

```
=== LitePB All Types Showcase ===

Step 1: Creating TypeShowcase message with all field types...
  ✓ Populated all field types

Step 2: Displaying original data...
  Scalar types:
    int32:   -42
    uint32:  4294967295
    sint32:  -2147483648 (zigzag)
    bool:    true
    string:  Hello, LitePB!
    ...

Step 3: Serializing to binary format...
  Serialized size: XXX bytes
  ...

Step 4: Deserializing from binary format...
  ✓ Parsing successful!

Step 5: Verifying all field types...
  Verifying scalar types...
    ✓ All scalar types match
  ...

=== ✓ SUCCESS: All types verified correctly! ===
```

## Key Concepts Demonstrated

### Zigzag Encoding (sint32/sint64)
```protobuf
sint32 field_sint32 = 5;  // Efficient encoding for negative numbers
```
Zigzag encoding maps signed integers to unsigned values, making small negative numbers efficient to encode.

### Fixed-Width Types
```protobuf
fixed32 field_fixed32 = 10;  // Always 4 bytes
fixed64 field_fixed64 = 11;  // Always 8 bytes
```
Use fixed-width types when values are often > 2^28 (for 32-bit) or when consistent wire size is needed.

### Repeated Fields
```protobuf
repeated int32 repeated_int32 = 18;              // Packed by default (proto3)
repeated int32 repeated_unpacked = 21 [packed = false];  // Unpacked
```
Proto3 uses packed encoding by default for repeated numeric types (more efficient).

### Map Fields
```protobuf
map<string, int32> map_string_int = 22;
map<string, Address> map_string_message = 23;
```
Maps are syntactic sugar for repeated entries with key/value fields.

### Oneof (Union Types)
```protobuf
oneof test_oneof {
    string oneof_string = 24;
    int32 oneof_int32 = 25;
    Address oneof_address = 26;
}
```
Only one field in a `oneof` can be set at a time. Setting a new field clears the previous one.

## When to Use Each Type

| Type | Best For | Wire Size |
|------|----------|-----------|
| `int32/int64` | Non-negative or small negative numbers | Variable (1-5 or 1-10 bytes) |
| `uint32/uint64` | Unsigned values | Variable (1-5 or 1-10 bytes) |
| `sint32/sint64` | Negative numbers | Variable (zigzag encoded) |
| `fixed32/fixed64` | Large numbers (>2^28) | Fixed (4 or 8 bytes) |
| `bool` | True/false | 1 byte |
| `string` | Text data | Length + UTF-8 bytes |
| `bytes` | Binary data | Length + raw bytes |
| `float/double` | Floating point | 4 or 8 bytes |
| `enum` | Named constants | Variable |
| `message` | Nested structures | Length + message bytes |

## Next Steps

- Review `proto/showcase.proto` to see all type definitions
- Study the verification code in `src/main.cpp` to understand type handling
- Try modifying values and re-running to see different encodings
- Explore the `examples/rpc/litepb_rpc/` example for RPC usage
