# LitePB Basic Serialization Example

A simple "Hello World" example demonstrating LitePB's core serialization capabilities.

## What This Example Shows

This example demonstrates the fundamental LitePB workflow:

1. **Define a message** - Simple `Person` message with name, age, and email fields
2. **Serialize** - Encode the message to binary format (Protocol Buffers wire format)
3. **Deserialize** - Decode the binary data back to a message
4. **Verify** - Confirm data integrity after the round-trip

## Files

- `proto/person.proto` - Protocol Buffer definition with a simple Person message
- `src/main.cpp` - Example code showing encode → decode → verify workflow
- `platformio.ini` - PlatformIO configuration for native platform

## How to Run

From this directory (`examples/serialization/basic/`), run:

```bash
pio run -e basic
.pio/build/basic/program
```

Or from the project root:

```bash
cd examples/serialization/basic && pio run -e basic && .pio/build/basic/program
```

## Expected Output

```
=== LitePB Basic Serialization Example ===

Step 1: Creating a Person message...
  Original data:
    Name:  Alice Johnson
    Age:   30
    Email: alice@example.com

Step 2: Serializing to bytes...
  Serialized size: 36 bytes
  Bytes (hex): 0a 0d 41 6c 69 63 65 20 4a 6f 68 6e 73 6f 6e 10 1e 1a 13 61 6c 69 63 65 40 65 78 61 6d 70 6c 65 2e 63 6f 6d

Step 3: Deserializing from bytes...
  Parsing successful!
  Decoded data:
    Name:  Alice Johnson
    Age:   30
    Email: alice@example.com

Step 4: Verifying data integrity...
  ✓ SUCCESS: Original and decoded data match perfectly!

=== Example Complete ===
```

## Key Concepts

**BufferOutputStream** - Dynamic buffer for serialization
```cpp
BufferOutputStream output;
serialize(person, output);
```

**BufferInputStream** - Buffer reader for deserialization
```cpp
BufferInputStream input(output.data(), output.size());
parse(decoded_person, input);
```

**Type-safe API** - Compiler catches type mismatches at compile time

## Next Steps

- Try the `examples/serialization/all_types/` example to see all supported Protocol Buffer types
- Explore the `examples/rpc/litepb_rpc/` example for RPC communication
