# Sensor Service RPC Example

This example demonstrates a complete end-to-end RPC implementation using LitePB's RPC layer. It showcases bidirectional communication between two peer nodes with real-world sensor use cases.

## Overview

The example implements a `SensorService` with two RPC methods:

1. **GetReading**: One peer requests sensor readings from another peer
2. **NotifyAlert**: One peer sends alerts to another peer when thresholds are exceeded

This demonstrates:
- ✅ Async callbacks with type-safe generated stubs
- ✅ Bidirectional RPC (both peers can initiate calls)
- ✅ Multiple transport options (LoopbackTransport, TCP, UART)
- ✅ Error handling with `Result<T>` types
- ✅ Event loop with `process()` for non-blocking operation

## Proto Definition

**File:** `proto/examples/sensor.proto`

```protobuf
syntax = "proto3";

package examples.sensor;

enum SensorStatus {
    OK = 0;
    WARNING = 1;
    ERROR = 2;
}

message ReadingRequest {
    int32 sensor_id = 1;
}

message ReadingResponse {
    int32 sensor_id = 1;
    float temperature = 2;
    SensorStatus status = 3;
}

message AlertEvent {
    int32 sensor_id = 1;
    float temperature = 2;
    SensorStatus status = 3;
    string message = 4;
}

message AlertAck {
    bool received = 1;
}

service SensorService {
    rpc GetReading(ReadingRequest) returns (ReadingResponse);
    rpc NotifyAlert(AlertEvent) returns (AlertAck);
}
```

## Building the Example

The example uses PlatformIO for building with a single environment:

```bash
# From examples/rpc/litepb_rpc directory:

# Build and run the example
pio run -e litepb_rpc -t exec

# Or just build
pio run -e litepb_rpc
```

## Running Tests

Tests for this example are located in the main project's `tests/platformio/examples/rpc/litepb_rpc/` directory. Due to PlatformIO limitations, they must be run from the **main project directory**:

```bash
# From the main project root:
cd /path/to/litepb

# Run all sensor example tests
pio test -e test_sensor_loopback -e test_sensor_service -e test_sensor_simulator -e test_sensor_integration

# Or run specific test suites
pio test -e test_sensor_loopback     # 7 tests: LoopbackTransport functionality
pio test -e test_sensor_service      # 8 tests: RPC method calls and bidirectional communication
pio test -e test_sensor_simulator    # 12 tests: SensorSimulator temperature thresholds
pio test -e test_sensor_integration  # 6 tests: Full client-server integration
```

**Note:** Running `pio test` from within the `examples/rpc/litepb_rpc` directory is not supported due to PlatformIO's handling of nested projects and library dependencies.

The proto file is automatically compiled to C++ by the PlatformIO build system using the `litepb_gen` tool.

## Running the Example

```bash
pio run -e litepb_rpc -t exec
```

**Output:**
```
=== Sensor RPC Bidirectional Example ===

Step 1: Setting up Peer B service handlers using SensorServiceServer...
Step 1b: Setting up Peer A NotifyAlert handler using SensorServiceServer...
Step 1c: Setting up Peer B SendAlert event handler (fire-and-forget)...

Step 2: Peer A calling GetReading RPC using SensorServiceClient (CLIENT_TO_SERVER)...
  [Peer B] Received GetReading request for sensor_id=42
  [Peer B] Sending response: temp=44.5, status=OK
  [Peer A] GetReading SUCCESS:
    Sensor ID: 42
    Temperature: 44.5°C
    Status: OK

Step 3: Peer A sending fire-and-forget alert using SensorServiceClient (SendAlert)...
  [Peer A] Fire-and-forget event sent: SUCCESS
  [Peer B] ALERT EVENT (fire-and-forget): Sensor 42 - Temperature high - fire-and-forget event!
           Temp: 85.5°C, Status: 1

Step 4: Peer B initiating NotifyAlert RPC using SensorServiceClient (SERVER_TO_CLIENT)...
  [Peer A] ALERT RECEIVED from sensor 42: Temperature critical - RPC with acknowledgment!
  [Peer A]   Temperature: 95.5, Status: 2
  [Peer B] NotifyAlert acknowledged by Peer A: YES

=== Example Complete ===

This example demonstrated bidirectional RPC using generated stubs:
  1. SensorServiceServer - Server-side handler interface
  2. SensorServiceClient - Client-side stub for making calls
  3. register_sensor_service() - Helper to register service handlers
  4. GetReading RPC - Peer A (0x01) to Peer B (0x02)
  5. NotifyAlert RPC - Peer B (0x02) to Peer A (0x01)
  6. SendAlert Event - Fire-and-forget from Peer A to Peer B
  7. Bidirectional peer-to-peer communication
  8. Type-safe generated stubs instead of call_internal/on_internal

Key differences from manual RPC calls:
  • No method IDs in user code (hidden in generated stubs)
  • Type-safe interfaces with compile-time checking
  • Cleaner, more maintainable code
  • Separation of concerns: client stubs vs server interfaces

Fire-and-forget vs RPC:
  • Fire-and-forget: No response, no acknowledgment, efficient for events
  • RPC: Expects response, provides acknowledgment, reliable but slower
```

## Code Walkthrough

### 1. Transport Setup

Both examples use `LoopbackTransport` for in-process communication (testing):

```cpp
LoopbackTransport client_transport;
LoopbackTransport server_transport;

// Connect transports for bidirectional communication
client_transport.connect_to_peer(&server_transport);
server_transport.connect_to_peer(&client_transport);
```

### 2. RPC Channel Creation

```cpp
// Peer A with local_address=1
RpcChannel peer_a_channel(peer_a_transport, 0x01, 1000);

// Peer B with local_address=2
RpcChannel peer_b_channel(peer_b_transport, 0x02, 1000);
```

Each node has a unique `local_address` used for message routing in peer-to-peer communication. Message IDs are simple incrementing counters managed internally by each channel.

### 3. Implementing Server Handlers

Both peers implement the `SensorServiceServer` interface:

```cpp
class PeerBSensorService : public SensorServiceServer {
public:
    Result<ReadingResponse> GetReading(const ReadingRequest& req) override {
        Result<ReadingResponse> result;
        result.value.sensor_id = req.sensor_id;
        result.value.temperature = 23.5f + (req.sensor_id * 0.5f);
        result.value.status = SensorStatus::OK;
        result.error.code = RpcError::OK;
        return result;
    }

    Result<AlertAck> NotifyAlert(const AlertEvent& req) override {
        std::cout << "ALERT: " << req.message << std::endl;
        Result<AlertAck> result;
        result.value.received = true;
        result.error.code = RpcError::OK;
        return result;
    }
};
```

### 4. Registering Service Handlers

```cpp
// Peer B service handlers
PeerBSensorService peer_b_service;
register_sensor_service(peer_b_channel, peer_b_service);

// Peer A service handlers (for NotifyAlert)
PeerBSensorService peer_a_service;
register_sensor_service(peer_a_channel, peer_a_service);
```

### 5. Making RPC Calls Using Client Stubs

```cpp
// Peer A calls GetReading on Peer B
SensorServiceClient peer_a_client(peer_a_channel);

ReadingRequest request;
request.sensor_id = 42;

peer_a_client.GetReading(request, [](const Result<ReadingResponse>& result) {
    if (result.ok()) {
        std::cout << "Temperature: " << result.value.temperature << std::endl;
    } else {
        std::cout << "Error: " << result.error.message << std::endl;
    }
});

// Peer B calls NotifyAlert on Peer A
SensorServiceClient peer_b_client(peer_b_channel);

AlertEvent alert;
alert.sensor_id = 42;
alert.temperature = 95.5f;
alert.status = SensorStatus::ERROR;
alert.message = "Temperature critical!";

peer_b_client.NotifyAlert(alert, [](const Result<AlertAck>& result) {
    if (result.ok()) {
        std::cout << "Alert acknowledged" << std::endl;
    }
});
```

### 6. Event Loop

Both peers must call `process()` regularly to handle incoming messages and timeouts:

```cpp
while (running) {
    peer_a_channel.process();  // Process Peer A messages
    peer_b_channel.process();  // Process Peer B messages
    
    // Your application logic here...
}
```

## Transport Options

The example uses `LoopbackTransport` for simplicity, but LitePB RPC supports multiple transports:

### TCP Transport (for Linux/macOS/Windows)

```cpp
#include "examples/rpc/tcp_transport.h"

// Create TCP client socket (see tcp_transport.h for helper functions)
int sockfd = create_tcp_client("127.0.0.1", 8080);
TcpTransport tcp_transport(sockfd);
RpcChannel rpc_channel(tcp_transport, 1);

// Main loop
while (running) {
    rpc_channel.process();
    // Make RPC calls...
}
```

### UART Transport (for Arduino/ESP32)

```cpp
#include "examples/rpc/uart_transport.h"

// Initialize Serial in setup()
Serial.begin(115200);
UartTransport uart_transport(Serial);
RpcChannel rpc_channel(uart_transport, 1);

void loop() {
    rpc_channel.process();
    // Make RPC calls...
}
```

### UDP Transport (for packet-based communication)

```cpp
#include "examples/rpc/udp_transport.h"

int sockfd = create_udp_socket(8080);
UdpTransport udp_transport(sockfd);
RpcChannel rpc_channel(udp_transport, 1);

while (running) {
    rpc_channel.process();
    // Make RPC calls...
}
```

## Key Concepts

### Async Callbacks

All RPC calls are asynchronous and non-blocking. Callbacks are invoked when responses arrive:

```cpp
client.GetReading(request, [](const Result<ReadingResponse>& result) {
    // This callback is invoked when the response arrives
    // or when the request times out
});

// Execution continues immediately (non-blocking)
```

### Bidirectional RPC

Both peer nodes can initiate RPC calls. This is useful for:
- Pushing notifications between peers
- Subscribing to events
- Peer-to-peer communication patterns

In the sensor example:
- **Peer A → Peer B**: `GetReading` (pull model)
- **Peer B → Peer A**: `NotifyAlert` (push model)

### Error Handling

The `Result<T>` type encapsulates both success and error states:

```cpp
if (result.ok()) {
    // Success: use result.value
    float temp = result.value.temperature;
} else {
    // Error: check result.error
    std::cout << "Error: " << result.error.message << std::endl;
}
```

Error codes:
- `RpcError::OK` - Success
- `RpcError::TIMEOUT` - Request timed out
- `RpcError::PARSE_ERROR` - Failed to parse message
- `RpcError::TRANSPORT_ERROR` - Transport layer failure
- `RpcError::HANDLER_NOT_FOUND` - No handler registered for method

### Type Safety

The RPC layer is fully type-safe. The compiler ensures:
- Request/response types match the proto definition
- Method names are correct
- All required fields are provided

```cpp
// Compile error if types don't match
client_channel.call_internal<WrongRequest, WrongResponse>(
    "GetReading", request, callback  // ❌ Compile error
);
```

## Adapting for Real Hardware

### ESP32 UART Example

```cpp
#include "examples/rpc/uart_transport.h"
#include "sensor.pb.h"

// Implement service
class MySensorService : public SensorServiceServer {
public:
    Result<ReadingResponse> GetReading(const ReadingRequest& req) override {
        Result<ReadingResponse> result;
        result.value.sensor_id = req.sensor_id;
        result.value.temperature = read_dht22_sensor();
        result.value.status = SensorStatus::OK;
        result.error.code = RpcError::OK;
        return result;
    }
};

UartTransport uart_transport(Serial);
RpcChannel rpc_channel(uart_transport, 1);
MySensorService service;

void setup() {
    Serial.begin(115200);
    
    // Register service handlers
    register_sensor_service(rpc_channel, service);
}

void loop() {
    rpc_channel.process();  // Handle incoming requests
}
```

### Raspberry Pi TCP Server

```cpp
#include "examples/rpc/tcp_transport.h"
#include "sensor.pb.h"

int main() {
    int server_fd = create_tcp_server(8080);
    int client_fd = accept_tcp_client(server_fd);
    
    TcpTransport tcp_transport(client_fd);
    RpcChannel rpc_channel(tcp_transport, 1);
    
    // Register handlers...
    
    while (true) {
        rpc_channel.process();
    }
}
```

## Next Steps

- Explore `examples/rpc/tcp_transport.h` for TCP implementation details
- Explore `examples/rpc/uart_transport.h` for UART/Serial implementation
- Read `docs/rpc.md` for detailed RPC design specification
- Create your own service definitions in `.proto` files
- Implement custom transports for your hardware (SPI, I2C, LoRa, etc.)

## Troubleshooting

### No response received

1. Ensure both channels call `process()` regularly
2. Check that handlers are registered before making calls
3. Verify method names match exactly (case-sensitive)
4. Increase timeout if network latency is high

### Compilation errors

1. Ensure proto file is in `proto/examples/` directory
2. Add proto file to `custom_litepb_protos` in `platformio.ini`
3. Verify C++17 support is enabled (`-std=c++17`)
4. Check that LitePB include paths are correct

### Transport issues

1. For UART: Verify baud rate matches on both ends
2. For TCP: Check firewall settings and port availability
3. For UDP: Ensure packet size doesn't exceed MTU
4. Test with LoopbackTransport first to isolate transport issues
