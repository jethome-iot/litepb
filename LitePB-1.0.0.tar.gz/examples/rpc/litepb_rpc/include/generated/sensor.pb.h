#ifndef LITEPB_GENERATED_SENSOR_H
#define LITEPB_GENERATED_SENSOR_H

#include "litepb/litepb.h"
#include <string>
#include <vector>
#include <cstdint>
#include <cstring>
#include <optional>
#include <variant>
#include <unordered_map>
#include <functional>
#include "litepb/rpc/channel.h"
#include "litepb/rpc/error.h"




namespace examples {

namespace sensor {



enum class SensorStatus : int32_t {
    OK = 0,
    WARNING = 1,
    ERROR = 2,
};

// Forward declarations
struct ReadingRequest;

struct ReadingResponse;

struct AlertEvent;

struct AlertAck;

struct AlertNotification;



struct ReadingRequest {
    int32_t sensor_id = 0;
};

struct ReadingResponse {
    int32_t sensor_id = 0;
    float temperature = 0.0f;
    SensorStatus status = static_cast<examples::sensor::SensorStatus>(0);
};

struct AlertEvent {
    int32_t sensor_id = 0;
    float temperature = 0.0f;
    SensorStatus status = static_cast<examples::sensor::SensorStatus>(0);
    std::string message = "";
};

struct AlertAck {
    bool received = false;
};

struct AlertNotification {
    int32_t sensor_id = 0;
    float temperature = 0.0f;
    SensorStatus status = static_cast<examples::sensor::SensorStatus>(0);
    std::string message = "";
};

// RPC Service Stubs

#define SENSORSERVICE_SERVICE_ID 1

// Client stub for SensorService (service_id=1)
class SensorServiceClient {
public:
    explicit SensorServiceClient(litepb::RpcChannel& channel)
        : channel_(channel) {}

    // service_id=1, method_id=1
    void GetReading(const ReadingRequest& request,
                      std::function<void(const litepb::Result<ReadingResponse>&)> callback,
                      uint32_t timeout_ms = 5000,
                      uint64_t dst_addr = 0) {
        channel_.call_internal<ReadingRequest, ReadingResponse>(
            1, 1, request, callback, timeout_ms, dst_addr);
    }

    // service_id=1, method_id=2
    void NotifyAlert(const AlertEvent& request,
                      std::function<void(const litepb::Result<AlertAck>&)> callback,
                      uint32_t timeout_ms = 5000,
                      uint64_t dst_addr = 0) {
        channel_.call_internal<AlertEvent, AlertAck>(
            1, 2, request, callback, timeout_ms, dst_addr);
    }

    // Fire-and-forget event senders
    // service_id=1, method_id=3
    bool SendAlert(const AlertNotification& event, uint64_t dst_addr = 0) {
        return channel_.send_event<AlertNotification>(1, 3, event, dst_addr);
    }

    // Event handler registration
    // service_id=1, method_id=3
    void onSendAlert(std::function<void(uint64_t, const AlertNotification&)> handler) {
        channel_.on_event<AlertNotification>(1, 3, handler);
    }

private:
    litepb::RpcChannel& channel_;
};

// Server interface for SensorService
class SensorServiceServer {
public:
    virtual ~SensorServiceServer() = default;

    virtual litepb::Result<ReadingResponse> GetReading(
        uint64_t src_addr,
        const ReadingRequest& request) = 0;

    virtual litepb::Result<AlertAck> NotifyAlert(
        uint64_t src_addr,
        const AlertEvent& request) = 0;

};

// EventServer interface for SensorService
class SensorServiceEventServer {
public:
    virtual ~SensorServiceEventServer() = default;

    virtual void SendAlertHandler(uint64_t src_addr, const AlertNotification& msg) {}

};

// Registration helper for SensorService (service_id=1)
inline void register_sensor_service(
    litepb::RpcChannel& channel,
    SensorServiceServer& server) {

    // service_id=1, method_id=1
    channel.on_internal<ReadingRequest, ReadingResponse>(
        1, 1,
        [&server](uint64_t src_addr, const ReadingRequest& request) {
            return server.GetReading(src_addr, request);
        });

    // service_id=1, method_id=2
    channel.on_internal<AlertEvent, AlertAck>(
        1, 2,
        [&server](uint64_t src_addr, const AlertEvent& request) {
            return server.NotifyAlert(src_addr, request);
        });
}

// Event registration helper for SensorService (service_id=1)
inline void register_sensor_service_events(
    litepb::RpcChannel& channel,
    SensorServiceEventServer* handler) {
    if (handler) {

        // service_id=1, method_id=3
        channel.on_event<AlertNotification>(
            1, 3,
            [handler](uint64_t src_addr, const AlertNotification& msg) {
                handler->SendAlertHandler(src_addr, msg);
            });
    }
}






}  // namespace sensor

}  // namespace examples



// Serializer specializations
namespace litepb {


template<>
struct Serializer<examples::sensor::ReadingRequest> {
    inline static bool serialize(const examples::sensor::ReadingRequest& value, litepb::OutputStream& stream) {
        litepb::ProtoWriter writer(stream);
        writer.write_tag(1, litepb::WIRE_TYPE_VARINT);
        writer.write_varint(static_cast<uint64_t>(value.sensor_id));
        return true;
    }

    inline static bool parse(examples::sensor::ReadingRequest& value, litepb::InputStream& stream) {
        litepb::ProtoReader reader(stream);
        uint32_t field_number;
        litepb::WireType wire_type;
        while (reader.read_tag(field_number, wire_type)) {
            
            switch (field_number) {
                case 1: {
                    uint64_t temp_varint;
                    if (!reader.read_varint(temp_varint)) return false;
                    value.sensor_id = static_cast<int32_t>(temp_varint);
                    break;
                }
                default:
                    if (!reader.skip_field(wire_type)) return false;
                    break;
            }
        }
        return true;
    }
};

template<>
struct Serializer<examples::sensor::ReadingResponse> {
    inline static bool serialize(const examples::sensor::ReadingResponse& value, litepb::OutputStream& stream) {
        litepb::ProtoWriter writer(stream);
        writer.write_tag(1, litepb::WIRE_TYPE_VARINT);
        writer.write_varint(static_cast<uint64_t>(value.sensor_id));
        writer.write_tag(2, litepb::WIRE_TYPE_FIXED32);
        writer.write_float(value.temperature);
        writer.write_tag(3, litepb::WIRE_TYPE_VARINT);
        writer.write_varint(static_cast<uint64_t>(value.status));
        return true;
    }

    inline static bool parse(examples::sensor::ReadingResponse& value, litepb::InputStream& stream) {
        litepb::ProtoReader reader(stream);
        uint32_t field_number;
        litepb::WireType wire_type;
        while (reader.read_tag(field_number, wire_type)) {
            
            switch (field_number) {
                case 1: {
                    uint64_t temp_varint;
                    if (!reader.read_varint(temp_varint)) return false;
                    value.sensor_id = static_cast<int32_t>(temp_varint);
                    break;
                }
                case 2: {
                    float temp;
                    if (!reader.read_float(temp)) return false;
                    value.temperature = temp;
                    break;
                }
                case 3: {
                    uint64_t enum_val;
                    if (!reader.read_varint(enum_val)) return false;
                    value.status = static_cast<decltype(value.status)>(enum_val);
                    break;
                }
                default:
                    if (!reader.skip_field(wire_type)) return false;
                    break;
            }
        }
        return true;
    }
};

template<>
struct Serializer<examples::sensor::AlertEvent> {
    inline static bool serialize(const examples::sensor::AlertEvent& value, litepb::OutputStream& stream) {
        litepb::ProtoWriter writer(stream);
        writer.write_tag(1, litepb::WIRE_TYPE_VARINT);
        writer.write_varint(static_cast<uint64_t>(value.sensor_id));
        writer.write_tag(2, litepb::WIRE_TYPE_FIXED32);
        writer.write_float(value.temperature);
        writer.write_tag(3, litepb::WIRE_TYPE_VARINT);
        writer.write_varint(static_cast<uint64_t>(value.status));
        writer.write_tag(4, litepb::WIRE_TYPE_LENGTH_DELIMITED);
        writer.write_string(value.message);
        return true;
    }

    inline static bool parse(examples::sensor::AlertEvent& value, litepb::InputStream& stream) {
        litepb::ProtoReader reader(stream);
        uint32_t field_number;
        litepb::WireType wire_type;
        while (reader.read_tag(field_number, wire_type)) {
            
            switch (field_number) {
                case 1: {
                    uint64_t temp_varint;
                    if (!reader.read_varint(temp_varint)) return false;
                    value.sensor_id = static_cast<int32_t>(temp_varint);
                    break;
                }
                case 2: {
                    float temp;
                    if (!reader.read_float(temp)) return false;
                    value.temperature = temp;
                    break;
                }
                case 3: {
                    uint64_t enum_val;
                    if (!reader.read_varint(enum_val)) return false;
                    value.status = static_cast<decltype(value.status)>(enum_val);
                    break;
                }
                case 4: {
                    std::string temp;
                    if (!reader.read_string(temp)) return false;
                    value.message = temp;
                    break;
                }
                default:
                    if (!reader.skip_field(wire_type)) return false;
                    break;
            }
        }
        return true;
    }
};

template<>
struct Serializer<examples::sensor::AlertAck> {
    inline static bool serialize(const examples::sensor::AlertAck& value, litepb::OutputStream& stream) {
        litepb::ProtoWriter writer(stream);
        writer.write_tag(1, litepb::WIRE_TYPE_VARINT);
        writer.write_varint(value.received ? 1 : 0);
        return true;
    }

    inline static bool parse(examples::sensor::AlertAck& value, litepb::InputStream& stream) {
        litepb::ProtoReader reader(stream);
        uint32_t field_number;
        litepb::WireType wire_type;
        while (reader.read_tag(field_number, wire_type)) {
            
            switch (field_number) {
                case 1: {
                    uint64_t temp_varint;
                    if (!reader.read_varint(temp_varint)) return false;
                    value.received = (temp_varint != 0);
                    break;
                }
                default:
                    if (!reader.skip_field(wire_type)) return false;
                    break;
            }
        }
        return true;
    }
};

template<>
struct Serializer<examples::sensor::AlertNotification> {
    inline static bool serialize(const examples::sensor::AlertNotification& value, litepb::OutputStream& stream) {
        litepb::ProtoWriter writer(stream);
        writer.write_tag(1, litepb::WIRE_TYPE_VARINT);
        writer.write_varint(static_cast<uint64_t>(value.sensor_id));
        writer.write_tag(2, litepb::WIRE_TYPE_FIXED32);
        writer.write_float(value.temperature);
        writer.write_tag(3, litepb::WIRE_TYPE_VARINT);
        writer.write_varint(static_cast<uint64_t>(value.status));
        writer.write_tag(4, litepb::WIRE_TYPE_LENGTH_DELIMITED);
        writer.write_string(value.message);
        return true;
    }

    inline static bool parse(examples::sensor::AlertNotification& value, litepb::InputStream& stream) {
        litepb::ProtoReader reader(stream);
        uint32_t field_number;
        litepb::WireType wire_type;
        while (reader.read_tag(field_number, wire_type)) {
            
            switch (field_number) {
                case 1: {
                    uint64_t temp_varint;
                    if (!reader.read_varint(temp_varint)) return false;
                    value.sensor_id = static_cast<int32_t>(temp_varint);
                    break;
                }
                case 2: {
                    float temp;
                    if (!reader.read_float(temp)) return false;
                    value.temperature = temp;
                    break;
                }
                case 3: {
                    uint64_t enum_val;
                    if (!reader.read_varint(enum_val)) return false;
                    value.status = static_cast<decltype(value.status)>(enum_val);
                    break;
                }
                case 4: {
                    std::string temp;
                    if (!reader.read_string(temp)) return false;
                    value.message = temp;
                    break;
                }
                default:
                    if (!reader.skip_field(wire_type)) return false;
                    break;
            }
        }
        return true;
    }
};


}  // namespace litepb

#endif  // LITEPB_GENERATED_SENSOR_H