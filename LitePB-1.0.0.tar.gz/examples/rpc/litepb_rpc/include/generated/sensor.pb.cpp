#include "litepb/litepb.h"
#include "sensor.pb.h"

namespace litepb {













}  // namespace litepb